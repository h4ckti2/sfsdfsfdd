<?php if(!defined('__CP__'))die();
define('LNG_SYS', 'Пользователь');

define('LNG_SYS_MAIN',     'Основные параметры');
define('LNG_SYS_LANGUAGE', 'Язык:');

define('LNG_SYS_SS',         'Параметры скриншотов');
define('LNG_SYS_SS_FORMAT',  'Формат:');
define('LNG_SYS_SS_QUALITY', 'Качество:');

define('LNG_SYS_PASSWORD',      'Смена пароля');
define('LNG_SYS_PASSWORD_OLD',  'Текущий пароль:');
define('LNG_SYS_PASSWORD_NEW1', 'Новый пароль:');
define('LNG_SYS_PASSWORD_NEW2', 'Подтверждение:');
define('LNG_SYS_PASSWORD_E1',   'Неверно указан старый пароль.');
define('LNG_SYS_PASSWORD_E2',   'Новый пароль и подтверждение не совпадают, попробуйте еще раз.');
define('LNG_SYS_PASSWORD_E3',   'Новый пароль должен содержать от %u до %u символов.');

define('LNG_SYS_SAVE', 'Сохранить');

define('LNG_SYS_UPDATED', 'Настройки успешно обновлены.');
?>